import Foundation
import XCTest

class TestCase: XCTestCase {
    func test() {
        XCTAssertEqual(
            false,
            isHaveDuplicates(arr: [0, 1, 2, 3, 4, 5, 6], maxDistance: 10)
        )
        
        XCTAssertEqual(
            true,
            isHaveDuplicates(arr: [0, 1, 2, 3, 4, 5, 0], maxDistance: 10)
        )
        
        XCTAssertEqual(
            false,
            isHaveDuplicates(arr:  [1, 0, 2, 3, 4, 5, 0], maxDistance: 4)
        )
        
        XCTAssertEqual(
            false,
            isHaveDuplicates(arr: [1, 1, 1, 1, 1, 1], maxDistance: 0)
        )
        
        XCTAssertEqual(
            false,
            isHaveDuplicates(arr: [0, 1, 2, 1, 3, 1, 4, 2, 4, 5, 0], maxDistance: 1)
        )
        
        XCTAssertEqual(
            true,
            isHaveDuplicates(arr: [3, 0, 8, 2, 3, 1, 4, 3, 9, 5, 0], maxDistance: 3)
        )
        
        XCTAssertEqual(
            true,
            isHaveDuplicates(arr: [0, 8, 2, 3, 1, 4, 3, 0, 5, 0], maxDistance: 2)
        )
    }
}


/*
 Let’s say we have an array of integer numbers “var arr: [Int]” and parameter maxDistance ”var maxDistance: Int”.
 The numbers at indexes i and j are considered as duplicates, if arr[i] == arr[j] and abs(i -j) <= maxDistance.
 The function "isHaveDuplicates" should check whether array "arr" has such duplicates or not.
 Returns "true", if duplicates are found.
 */
func isHaveDuplicates(arr: [Int], maxDistance: Int) -> Bool {
    // TODO write function body
    
    return false
}


TestCase.defaultTestSuite.run()




